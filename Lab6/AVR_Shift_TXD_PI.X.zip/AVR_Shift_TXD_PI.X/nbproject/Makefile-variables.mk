#
# Generated - do not edit!
#
# NOCDDL
#
CND_BASEDIR=`pwd`
# default configuration
CND_ARTIFACT_DIR_default=dist/default/production
CND_ARTIFACT_NAME_default=AVR_Shift_TXD_PI.X.production.hex
CND_ARTIFACT_PATH_default=dist/default/production/AVR_Shift_TXD_PI.X.production.hex
