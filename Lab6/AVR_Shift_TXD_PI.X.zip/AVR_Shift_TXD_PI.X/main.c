/*
 * Created on February 27, 2021, 7:49 PM
 */


#define BOARD_PROT_MPIDE_NPP 3

//pentru placa de dezvoltare
#if (BOARD_PROT_MPIDE_NPP == 3)
#define F_CPU 16000000
#define DlyTime_NPP 52 //=1/19200 = 52         69,44 si scadem 1-2 us
#define DELAY_NPP(X) _delay_us(X)
#define TMR1PERIOD 15999

//pentru Proteus
#elif (BOARD_PROT_MPIDE_NPP == 2)
#define DlyTime_NPP 208 //208,25
#define DELAY_NPP(X) _delay_us(X)
#define TMR1PERIOD 7999

//pentru MPIDE SIM
#elif (BOARD_PROT_MPIDE_NPP == 1)
#define DlyTime_NPP 208 //208,25
#define DELAY_NPP(X) _delay_us(X)
#define TMR1PERIOD 100
#endif


#include <avr/io.h>
#include <avr/interrupt.h>
#include <util/delay.h>
#include "Uno_Nano_utils.h"
#include "Buttons.h"

//Variabilele pentru butoane - Extern
extern enum BtnFlagTypes BtnFlag[NumButtons];
extern unsigned short BtnTimeCount[NumButtons];

#define SECV 0x50
uint8_t Val = SECV;
uint8_t i = 0;

//                  P     I     CR    LF
char HelloMsg1[4]={0x50, 0x49, 0x0D, 0x0A};
const char HelloMsg2[]="Pascale Iulian\r\n";
const char * pMsg;

void SecvTransm(uint8_t Val);
void ConfigureandStartTimer1();

int main(void) {
    //iesiri
    BitSet(DDRD, DDD1);
    //valoare initiala PD1 = 1 - TXD
    BitSet(PORTD, PD1);
    DELAY_NPP(DlyTime_NPP);
    
    Init_Buttons();
    ConfigureandStartTimer1();
    sei();
    
while (1) {
        if (BtnFlag[Btn1] == Click) {
            SecvTransm(SECV);
            BtnFlag[Btn1] = BtnIdle;
        }

        if (BtnFlag[Btn2] == Click) {
            SecvTransm(0x49);
            BtnFlag[Btn2] = BtnIdle;
        }
        
        if (BtnFlag[Btn1] == LPress) {
            for (i = 0; i < 4; i++) 
                SecvTransm((uint8_t)HelloMsg1[i]);
            
            BtnFlag[Btn1] = BtnIdle;
        }
        if (BtnFlag[Btn2] == LPress) {
            pMsg = HelloMsg2;
            while(*pMsg){
                SecvTransm((uint8_t)(*pMsg));
                pMsg++;
            }
            BtnFlag[Btn2] = BtnIdle;
        }
    }


    return 0;
}

void SecvTransm(uint8_t Val){
    uint16_t Temp = Val;
    uint8_t i = 0;
    
    //asamblam: 0 pe LSB, Val: pe bitii 1..8, 1 pe bit 9
    Temp = (Val<<1) | (1<<9);
    
    //in timp ce transmitem, sa nu avem intraruperi!
    cli();
    //Transmitem 10 biti, doar pe Out1, LSB first
    for (i = 0; i < 10; i++){
     
       //Atribuire PD1 = TXD
        if ( Temp & 0x01 ) PORTD = PORTD | (1 << PD1);
        else PORTD = PORTD & (~(1 << PD1));
        Temp = Temp >> 1;
   
        DELAY_NPP(DlyTime_NPP);
    
    }
    //Dupa transmisie, permitem din nou intreruperi
    sei();
}

  ISR (TIMER1_COMPA_vect){
 
 enum Buttons Btn;
    //incrementam BtnTimeCount si rulam BtnFsm()
    //pentru fiecare buton
    for (Btn = Btn1; Btn < NumButtons; Btn++){
        BtnTimeCount[Btn]++;
       BtnFSM(Btn);
    }
    
}


void ConfigureandStartTimer1(){
//Stergem configuratiile si resetam Timer
TCCR1A = 0;
TCCR1B = 0;
TCNT1 = 0; 
//Setam Perioada, vezi definitia
//la inceputul fisierului
OCR1A = TMR1PERIOD;
        
//Modul de lucru: CTC
BitSet(TCCR1B, WGM12);

// Valideaza Timer1 Interrupt pe Compare Match
BitSet(TIMSK1, OCIE1A);

//Alegem Prescaler=1 si pornim Timer
BitSet(TCCR1B, CS10);
}