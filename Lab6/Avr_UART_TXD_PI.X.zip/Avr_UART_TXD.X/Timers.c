
/* 
 * File:   
 * Author: 
 * Comments:
 * Revision history: 
 */


#include <avr/io.h>
#include <avr/interrupt.h>
#include "Uno_Nano_utils.h" 
#include "Timers.h"

extern enum BtnFlagTypes BtnFlag[NumButtons];
extern unsigned short BtnTimeCount[NumButtons];

void ConfigureTimer0(){
 //Stergem configuratiile si resetam Timer
TCCR0A = 0;
TCCR0B = 0;
TCNT0 = 0; 

//Modul de lucru: CTC
BitSet(TCCR0A, WGM01);

//Perioada: 1ms
#if (SIM_PROTEUS) //CLK = 8MHz, 8MHz/1KHz=8000 
                  //Rata de divizare = (OCR0A+1)*Prescaler
                  //Daca alegem Prescaler = 64, rezulta OCR0A = 8000/64 - 1 = 124
    OCR0A = 124;
#else //CLK = 16MHz, 16MHz/1KHz = 16000
      //Rata de divizare = (OCR0A+1)*Prescaler
      //Daca alegem Prescaler = 64 avem OCR0A = 16000/64 - 1 = 249

    OCR0A = 249;
#endif 

//Validam intreruperile pentru Timer0 COMPA
BitSet(TIMSK0, OCIE0A);

//Alegem Prescaler si pornim Timer
    BitSet(TCCR0B, CS00);
    BitSet(TCCR0B, CS01);
  
    
}

ISR (TIMER0_COMPA_vect){
 enum Buttons Btn;
     //Sa nu uitam update pentru OCR2B

     for (Btn = Btn1; Btn < NumButtons; Btn++){
        BtnTimeCount[Btn]++;
       BtnFSM(Btn);
    }    
}
