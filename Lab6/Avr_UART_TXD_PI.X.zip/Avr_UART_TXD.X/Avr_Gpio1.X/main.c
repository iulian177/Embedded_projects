

/*
 * File:   main.c
 * Author: Albertf
 *
 * Created on February 27, 2021, 3:01 PM
 */

#define F_CPU 1000000


#include <avr/io.h>

#include <util/delay.h>


int main(void) {
    
    DDRD = 0x04;
    
    while (1) {
       PORTD = 0x04;
       _delay_us(500);
       PORTD = 0x00;
       _delay_us(500);
       
    }
}


