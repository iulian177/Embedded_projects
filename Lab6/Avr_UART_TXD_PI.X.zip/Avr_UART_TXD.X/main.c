

/*
 * File:   main.c
 * Author: Albertf
 *
 * Created on February 27, 2021, 3:01 PM
 */



#include <xc.h> // include processor files - each processor file is guarded.  
#include "Avr_UART_TXD.h"
#include <avr/io.h>
#include <avr/interrupt.h>
#include <util/delay.h>
#include "Uno_Nano_utils.h"

#include "Buttons.h"
#include "Timers.h"
#include "ATMega_Uart.h"

extern enum BtnFlagTypes BtnFlag[NumButtons];

int i;

//                 P     I       CR    LF
char HelloMsg1[4]={0x49, 0x50,  0x0D, 0x0A};
const char HelloMsg2[]="Iulian Pascale\r\n";
const char * pMsg;



int main(void) {
    //Directia
    BitSet(Out1DD, Out1bit);
    //Valoarea initiala = 1
    BitSet(Out1PORT, Out1bit);

    Init_Buttons();
    ConfigureTimer0();
    ConfigureUart();
    
    sei();

    while (1) {
        if (BtnFlag[Btn1] == Click) {
            TransmUART(0x49);
            BtnFlag[Btn1] = BtnIdle;
        }

        if (BtnFlag[Btn2] == Click) {
            TransmUART(0x50);
            BtnFlag[Btn2] = BtnIdle;
        }
        
        if (BtnFlag[Btn1] == LPress) {
            for (i = 0; i < 4; i++) 
                TransmUART(HelloMsg1[i]);
            
            BtnFlag[Btn1] = BtnIdle;
        }
        if (BtnFlag[Btn2] == LPress) {
            pMsg = HelloMsg2;
            while(*pMsg){
                TransmUART(*pMsg);
                pMsg++;
            }
            BtnFlag[Btn1] = BtnIdle;
        }
    }
}



