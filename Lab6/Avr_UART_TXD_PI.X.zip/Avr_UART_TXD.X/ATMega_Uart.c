/* ************************************************************************** */
/** Descriptive File Name

  @Company
    UTCN

  @File Name
    Uno_Nano_utils.c

  @Description
        This library implements the delay functionality used in other libraries.  
        The delay is implemented using loop, so the delay time is not exact. 
        For exact timing use timers.
        Include the file in the project, together with utils.h, when this library is needed	
 */
/* ************************************************************************** */

/* ************************************************************************** */
/* ************************************************************************** */
/* Section: Included Files                                                    */
/* ************************************************************************** */

#include <avr/io.h>
#include "Uno_Nano_utils.h"
#include "ATMega_Uart.h"
/* ************************************************************************** */

void ConfigureUart(){

    BitSet(DDRD, DDD1);//TXD = PD1 - iesire
    //Foarte important: Linia in Idle este 1 logic!
    BitSet(PORTD, PD1);
    
    UBRR0H = 0;
    UBRR0L = 16;//pentru BAUDRATE = 57600
    
    //Pentru 8 biti UCSZ0[2:0]=011
   // BitSet(UCSR0C, UCSZ01);
   // BitSet(UCSR0C, UCSZ02);
    
    //BitSet(UCSR0C, UPM01); // seteaza paritatea impara
    //BitSet(UCSR0C, UPM00);
    
    //Validam receptia si transmisia
    BitSet(UCSR0B, TXEN0);
    BitSet(UCSR0B, RXEN0);
    
}

void TransmUART(char data){
  //Asteptam, pana registrul de date e gol  
  while (bit_is_clear(UCSR0A, UDRE0));
  UDR0 = data;//Daca e gol, trimitem un caracter 
}


/* *****************************************************************************
 End of File
 */
