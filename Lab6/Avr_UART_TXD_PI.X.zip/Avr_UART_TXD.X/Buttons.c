
/* 
 * File:   
 * Author: 
 * Comments:
 * Revision history: 
 */


#include <avr/io.h>
#include <avr/interrupt.h>
#include "Uno_Nano_utils.h" 
#include "Buttons.h"

volatile enum BtnFsmStates BtnFSMState[NumButtons];

volatile enum BtnValues BtnVal[NumButtons];

volatile enum BtnFlagTypes BtnFlag[NumButtons];

volatile unsigned short BtnTimeCount[NumButtons];

//Btn1 e conectat la PD3, Btn2 la PC1
uint8_t  * BTN_PIN_REGS[NumButtons]={(uint8_t *)_SFR_ADDR(PIND), //port D pentru Btn1
                                     (uint8_t *)_SFR_ADDR(PINC)};//port C pentru Btn2

const uint8_t  BTN_PINS[NumButtons] ={PIND3, PINC1};


//PD3 = PCINT19 - pe registrul PCMSK2
//PC1 = PCINT9 - pe registrul PCMSK1
//Pentru a determina PCMSK, vei Datasheet->Interrupts->External Interrupts - pag. 57

//La apasarea Btn1 se va lansa ISR PCINT2
ISR(PCINT2_vect){
enum Buttons Btn = Btn1;
    if ( (BtnVal[Btn] == BtnReleased) &&
         (bit_is_set_onAddr(BTN_PIN_REGS[Btn], BTN_PINS[Btn])) ){
        
        if (BtnTimeCount[Btn] >= STABLE_TIME_TICKS) BtnVal[Btn]=BtnPressed;
        BtnTimeCount[Btn]=0;
    }
    if ( (BtnVal[Btn] == BtnPressed) &&
         (bit_is_clear_onAddr(BTN_PIN_REGS[Btn], BTN_PINS[Btn])) ){
        
        if (BtnTimeCount[Btn] >= STABLE_TIME_TICKS) BtnVal[Btn]=BtnReleased;
        BtnTimeCount[Btn]=0;
    }

}

//La apasarea Btn2 se va lansa ISR PCINT1
ISR(PCINT1_vect){
enum Buttons Btn = Btn2;
    if ( (BtnVal[Btn] == BtnReleased) &&
         (bit_is_set_onAddr(BTN_PIN_REGS[Btn], BTN_PINS[Btn])) ){
        if (BtnTimeCount[Btn] >= STABLE_TIME_TICKS) BtnVal[Btn]=BtnPressed;
        BtnTimeCount[Btn]=0;
    }
    if ( (BtnVal[Btn] == BtnPressed) &&
         (bit_is_clear_onAddr(BTN_PIN_REGS[Btn], BTN_PINS[Btn])) ){
        if (BtnTimeCount[Btn] >= STABLE_TIME_TICKS) BtnVal[Btn]=BtnReleased;
        BtnTimeCount[Btn]=0;
    }
}


ISR(PCINT0_vect){
//E deocamdata gol,
//vom folosi, doar daca avem buton pe PCMSK0
}


void BtnFSM(enum Buttons Btn){
    switch (BtnFSMState[Btn]){
    case stBtnIdle: if (BtnVal[Btn] == BtnPressed) 
                        BtnFSMState[Btn] = stBtnPressed;
                    break;
    case stBtnPressed: if (BtnVal[Btn] != BtnPressed){
                            BtnFSMState[Btn] = stBtnClick;
                            BtnFlag[Btn] = Click;
                        }
                      else
                        if(BtnTimeCount[Btn] == LONGPRESS_TICKS){
                               BtnFSMState[Btn] = stBtnLongPress;
                               BtnFlag[Btn] = LPress;
                        }
                    break;
    case stBtnClick: if (BtnTimeCount[Btn] >= DBLCLICK_TIMEOUT_TICKS)
                                BtnFSMState[Btn] = stBtnIdle;
                         else if(BtnVal[Btn] == BtnPressed){
                             BtnFSMState[Btn] = stBtnDblClick;
                             BtnFlag[Btn] = DblClick;
                         }
                         break;
    case stBtnDblClick: if (BtnVal[Btn] == BtnReleased)
                        BtnFSMState[Btn] = stBtnIdle;
                        break;
    case stBtnLongPress: if (BtnVal[Btn] == BtnReleased){
                            BtnFSMState[Btn] = stBtnIdle;
                            BtnFlag[Btn] = LpRelease;
                        }
                       break;
    default : break;
    } 
}

void Init_Buttons(){
    enum Buttons Btn;
    //Initializam toate variabilele legate de butoane
    for (Btn = Btn1; Btn < NumButtons; Btn++){
        BtnFSMState[Btn]= stBtnIdle;
        BtnVal[Btn]=BtnReleased;
        BtnFlag[Btn]=BtnIdle;
        BtnTimeCount[Btn]=0;
    } 
    
    BitSet(PCMSK2, PCINT19); //PCINT19 = PD3, Btn1
    BitSet(PCMSK1, PCINT9); //PCINT9 = PC1, Btn2
    
    BitSet(PCICR, PCIE2);    //Validam vectorul de intrerupere, 
                             //care contine bitul PCINT19: PCIE2
    BitSet(PCICR, PCIE1);    //Validam vectorul de intrerupere, 
                             //care contine bitul PCINT9: PCIE1
    
}


