

/*
 * File:   main.c
 * Author: Albertf
 *
 * Created on February 27, 2021, 3:01 PM
 */

#define F_CPU 1000000
#include <avr/io.h>
#include <util/delay.h>
#include <avr/interrupt.h>
#include "Uno_Nano_utils.h"
#include "Avr_Btn_Secv.h"

volatile uint8_t BtnPressed = 0;
volatile int RefTemp = 21;

int main(void) {

    
    BitSet(PCMSK2, PCINT19); //Validam intreruperi pe pinul PCINT19
    BitSet(PCICR, PCIE2);    //Validam vectorul de intrerupere PCINT2
	//PCIFR = 0x07;          //Stergem Flag-urile
    
	sei();                   //Validam global intreruperile

    
    while(1){
        if (BtnPressed){
            RefTemp = RefTemp +1;
            
            BtnPressed = 0;
        }
               
   
    }  
}


ISR(PCINT2_vect){
    
    if (bit_is_set(PIND, PIND3)){
        BtnPressed = 1;
    }
    
}