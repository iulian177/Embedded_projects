/* 
 * File:   
 * Author: 
 * Comments:
 * Revision history: 
 */

#include "ssd.h"
#include <avr/io.h>
#include <avr/interrupt.h>
#include "Uno_Nano_utils.h" 

/* ************************************************************************** */
//Sirul care contine decodificarea HEX-7 Segmente
// Bit 0 - Catod A: 0 pentru a aprinde, 1 pentru a stinge
// Bit 1 - Catod B: 0 pentru a aprinde, 1 pentru a stinge
// Bit 2 - Catod C: 0 pentru a aprinde, 1 pentru a stinge
// Bit 3 - Catod D: 0 pentru a aprinde, 1 pentru a stinge
// Bit 4 - Catod E: 0 pentru a aprinde, 1 pentru a stinge
// Bit 5 - Catod F: 0 pentru a aprinde, 1 pentru a stinge
// Bit 6 - Catod G: 0 pentru a aprinde, 1 pentru a stinge
// Bit 7 - Catod DP - punctul zecimal, va fi tratat separat
const unsigned char digitSegments[]= {
    0b1000000, // 0
    0b1111001, // 1
    0b0100100, // 2
    0b0110000, // 3
    0b0011001, // 4
    0b0010010, // 5
    0b0000010, // 6
    0b1111000, // 7
    0b0000000, // 8
    0b0010000, // 9
    0b0001000, // A
    0b0000011, // b
    0b1000110, // C
    0b0100001, // d
    0b0000110, // E
    0b0001110, // F
    0b0001001  // H
};


//Alocarea pinilor in aceasta biblioteca
//Segmenti
// DP  G   F   E   D   C   B   A
//PC1 PB1 PB3 PB2 PD7 PD6 PD5 PD4

//Cathode data Direction Ports and Pins
uint8_t  * CAT_DDR_REGS[8]={(uint8_t *)_SFR_ADDR(DDRD), //A
                            (uint8_t *)_SFR_ADDR(DDRD), //B
                            (uint8_t *)_SFR_ADDR(DDRD), //C
                            (uint8_t *)_SFR_ADDR(DDRD), //D
                            (uint8_t *)_SFR_ADDR(DDRB), //E
                            (uint8_t *)_SFR_ADDR(DDRB), //F
                            (uint8_t *)_SFR_ADDR(DDRB), //G
                            (uint8_t *)_SFR_ADDR(DDRC)};//DP 
                                //A     B     C     D 
const uint8_t  CAT_DDR_PINS[8] ={DDD4, DDD5, DDD6, DDD7,
                                //E     F     G     DP
                                 DDB2, DDB3, DDB1, DDC1};
//Cathode Ports and Pins
uint8_t  * CAT_PORT_REGS[8]={(uint8_t *)_SFR_ADDR(PORTD), //A 
                             (uint8_t *)_SFR_ADDR(PORTD), //B
                             (uint8_t *)_SFR_ADDR(PORTD), //C
                             (uint8_t *)_SFR_ADDR(PORTD), //D
                             (uint8_t *)_SFR_ADDR(PORTB), //E
                             (uint8_t *)_SFR_ADDR(PORTB), //F
                             (uint8_t *)_SFR_ADDR(PORTB), //G
                             (uint8_t *)_SFR_ADDR(PORTC)};//DP
                                 //A        B       C       D
const uint8_t  CAT_PORT_PINS[8] ={PORTD4, PORTD5, PORTD6, PORTD7,
                                 //E        F       G       DP
                                 PORTB2, PORTB3, PORTB1, PORTC1};

//Anozi
//AN3 AN2 AN1 AN0
//PC2 PC3 PC4 PC5
//Anode data Direction Ports and Pins
uint8_t  * AN_DDR_REGS[4]={ (uint8_t *)_SFR_ADDR(DDRC), //AN0
                            (uint8_t *)_SFR_ADDR(DDRC), //AN1
                            (uint8_t *)_SFR_ADDR(DDRC), //AN2
                            (uint8_t *)_SFR_ADDR(DDRC)};//AN3
                               //AN0   AN1   AN2   AN3 
const uint8_t  AN_DDR_PINS[4] ={DDC5, DDC4, DDC3, DDC2};
//Anode Ports and Pins
uint8_t  * AN_PORT_REGS[4]={ (uint8_t *)_SFR_ADDR(PORTC), //AN0 
                             (uint8_t *)_SFR_ADDR(PORTC), //AN1
                             (uint8_t *)_SFR_ADDR(PORTC), //AN2
                             (uint8_t *)_SFR_ADDR(PORTC)};//AN3
                                 //AN0     AN1     AN2     AN3
const uint8_t  AN_PORT_PINS[4] ={PORTC5, PORTC4, PORTC3, PORTC2};


/* ************************************************************************** *

//Variabile globale pentru afisajul de 7 Segmente

* ************************************************************************** */
//valoarea celor 4 digiti, care vor fi afisati
volatile uint8_t digits[4];

//1 logic pe bitii [3:0] ai DecimalPoint 
//aprinde punctul zecimal pe digitul respectiv
//exemplu: 0b0010 aprinde DP pe Digit 1
//0b0110 aprinde DP pe Digit 1 si 2
volatile uint8_t DecimalPoint;

//1 logic pe bitii [3:0] ai BlankDigit stinge digitul respectiv
//exemplu: 0b1000 stinge digitul cel mai semnificativ,
//0b1001 stinge digitii 3 si 0 samd.
volatile uint8_t BlankDigit = 0;

//Pentru a genera o pauza intre aprinderea,
//pe rand, a anozilor. Trebuie doar in simularea Proteus!
volatile uint8_t AnodePause = 0;
//Endisplay = 0 stinge, 1 aprinde afisajul
volatile uint8_t EnDisplay = 0;


/* ************************************************************************** *

Corpurile functiilor

* ************************************************************************** */

/* ************************************************************************** *
 * void init_Display()
 * Configurarea iesirilor si a Timer-ului
 * ************************************************************************** */
void init_SSD(){
    uint8_t i;

//Alocarea pinilor in aceasta biblioteca
//Segmenti
// DP  G   F   E   D   C   B   A
//PC1 PB1 PB3 PB2 PD7 PD6 PD5 PD4
//Anozi
//AN3 AN2 AN1 AN0
//PC2 PC3 PC4 PC5
    
    //Setam ca iesire catozii
    for (i=0; i < 8; i++){
        BitSet_onAddr(CAT_DDR_REGS[i], CAT_DDR_PINS[i]);
        //1 logic pe segmenti, ca initial sa fie stinsi
        BitSet_onAddr(CAT_PORT_REGS[i], CAT_PORT_PINS[i]);
    }

    //Setam ca iesire anozii
    for (i=0; i < 4; i++){
        BitSet_onAddr(AN_DDR_REGS[i], AN_DDR_PINS[i]);
        //0 logic pe anozi ca initial sa fie stinsi
        BitClear_onAddr(AN_PORT_REGS[i], AN_PORT_PINS[i]);
    }

}


/*******************************************************************
 * Functia, care asigura refresh la digiti
 * A se apela intr-o intrerupere Timer
 *******************************************************************/
void RefreshDigits(){
static unsigned char idxCurrentDigit = 0;
unsigned char idx;
uint8_t i;

if (EnDisplay)   {//Aprindem afisajul, doar daca EnDisplay = 1
    if (!AnodePause){//Pentru a insera o pauza - necesar in simularea
                     //Proteus

        idx = (idxCurrentDigit++) & 3;
       
      //Trimitem pe catozi codul Seven Segment al digit-ului curent 
       DisplaySingleDigit(digits[idx], DecimalPoint & (1 << idx));

       //Walk1 pe anozi
       //Stingem toti digiti, apoi aprindem digitul curent
       for (i=0; i < 4; i++) 
           BitClear_onAddr(AN_PORT_REGS[i], AN_PORT_PINS[i]);
       
       //Daca bitul corespunzator al BlankDigit e 0,
       //atunci aprindem anodul curent
       if( !(BlankDigit & (1<<idx)) ) BitSet_onAddr(AN_PORT_REGS[idx], AN_PORT_PINS[idx]);
       
       AnodePause = 1;
     }
    else{//la if (!AnodePause)
        //inseram o pauza la anozi - e nevoie de ea in simularea Proteus        
          AnodePause = 0;
         for (i=0; i < 4; i++) 
           BitClear_onAddr(AN_PORT_REGS[i], AN_PORT_PINS[i]);
        }
 }
else{ //la if(EnDisplay)
    for (i=0; i < 4; i++) 
      BitClear_onAddr(AN_PORT_REGS[i], AN_PORT_PINS[i]);

}
}

/* ************************************************************************** *
 * void DisplaySingleDigit(uint8_t Number, uint8_t DP){
 * Decodifica si trimite codul de 7 segmenti pe catozi
 * Argumente:
 *  Number: de la 0 la 0xF, care va fi cofdificat in 7 segmente
 *  DP: pentru 1 aprinde, pentru 0 stinge puctul zecimal
* ************************************************************************** */
void DisplaySingleDigit(uint8_t Number, uint8_t DP){
uint8_t i;

//Alocarea segmentilor in aceasta biblioteca
// DP  G   F   E   D   C   B   A
//PC1 PB1 PB3 PB2 PD7 PD6 PD5 PD4

 //Number va fi index in sirul digitSegments[]
 //Nu are voie, sa depaseasca 15
 //Cel mai simplu: Mascam Number cu 0x0F
 uint8_t SegData =  digitSegments[Number & 0x0F];
 
    //trimitem bitii lui SegData spre catozi, inversat
    for (i=0; i < 7; i++){
        if( SegData & (1<< i) )
            BitSet_onAddr(CAT_PORT_REGS[i], CAT_PORT_PINS[i]);
        else
            BitClear_onAddr(CAT_PORT_REGS[i], CAT_PORT_PINS[i]);
    }
    //Pentru DP: Logica nu e inversa: Daca DP=1, aprindem Decimal POint
    if(DP) BitClear_onAddr(CAT_PORT_REGS[7], CAT_PORT_PINS[7]);
    else BitSet_onAddr(CAT_PORT_REGS[7], CAT_PORT_PINS[7]); 
   
}


 /* ***************************************************************************
 * void DisplayRawNumber(uint16_t Number, uint8_t DP)
 * Afiseaza un numar de 16 biti pe 4 digiti (neformatat, adica in hexazecimal)
 * Argumente:
 *  Number: fiecare grup de 4 biti ai acestuia va fi decodificat
 *          si afisat pe afisajul de 7 segmente, 4 digiti:
 *          bit [15:12]-Digit3, bit [11:8]-Digit2, bit [7:4]-Digit1,
 *          bit [3:0]-Digit0
 *  DP: bit 3 aprinde punctul zecimal de la Digit3
 *      bit 2 aprinde punctul zecimal de la Digit2 samd
* ***************************************************************************/
void DisplayRawNumber(uint16_t Number, uint8_t DP){
   uint8_t i;
   //in timp ce actualizam digits[i], o intrerupere
   //ar putea lansa din nou aceasta functie 
   //si ar interfera cu valorile digits[i]
   
   //sa evitam acest lucru
   cli();
   DecimalPoint = DP;
   
   for (i = 0; i <4; i++){
      digits[i] = (Number & (0x0F << (4*i)) ) >> (4*i);
   }
  
   //dupa ce am actualizat digits[i] si DecimalPoint,
   //sa permitem din nou intreruperile
   sei();
}

 /* ***************************************************************************
 * uint16_t Format4DigitBCDNumber(uint16_t Number)
 * Formateaza un numar pe 16 biti intr-un numar in BCD (zecimal)
 * Argumente:
 *  Number: Numarul de formatat
 * 
  * Valoarea de retur:
  *     Numarul in format BCD
  * Daca Number >9999, atunci numarul returnat va afisa doar primele
  * 3 cifre seminficative, iar pe bitii [15:12] va aparea 0xE (Eroare) 
* ***************************************************************************/
uint16_t Format4DigitBCDNumber(uint16_t Number){
   uint16_t Temp=Number, Num10Disp=0;
   uint8_t i = 0;
   
   while(Temp!=0){//Desfacem Temp in valori BCD
       //Valoarea BCD = restul impartirii la 10
       //Noua cifra ajunge pe pozitia cea mai semnificativa
       Num10Disp = Num10Disp | ((Temp % 10)<<12)  ;
       Temp = Temp /10;
       if (Temp!=0) Num10Disp = Num10Disp >> 4;
       i++;
   }
   if (i<=4){
   //Am avut o cifra  < 9999. Atunci deplasam Num10Disp, 
   //astfel ca unitatile sa ajunga 
   //pe pozitia cea mai putin semnificativa
       Num10Disp = Num10Disp >> (4 * (4-i));
   }
   else{
   ///Am avut o cifra  >= 10000. 
   //Atunci afisam doar 3 cifre cele mai semnificative, 
   //iar pe prima pozitie afisam E
       Num10Disp = (Num10Disp >> 4) | 0xE000;
   }
    
   return Num10Disp;
}

 /* ***************************************************************************
  * void DisplayOff()
  * Stinge afisajul 
* ***************************************************************************/
void DisplayOff(){

   EnDisplay = 0;
}
 /* ***************************************************************************
  * void DisplayOn()
  * Aprinde afisajul 
* ***************************************************************************/
void DisplayOn(){

   EnDisplay = 1;
}

 /* ***************************************************************************
  * void TurnOffDigit(uint8_t Digit_Num)
  * Stinge un digit din afisaj
  * Argumente:
  *     Digit_Num: Numarul digit-ului de stins, 0..3
  * Daca Digit_Num >3, functia nu va avea efect 
* ***************************************************************************/
void TurnOffDigit(uint8_t Digit_Num){
    if (Digit_Num < 4){
        BlankDigit = BlankDigit | (1 << Digit_Num);
    }
}

 /* ***************************************************************************
  * void TurnOnDigit(uint8_t Digit_Num)
  * Aprinde un digit din afisaj
  * Argumente:
  *     Digit_Num: Numarul digit-ului de aprins, 0..3
  * Daca Digit_Num >3, functia nu va avea efect 
* ***************************************************************************/
void TurnOnDigit(uint8_t Digit_Num){
    if (Digit_Num < 4){
        BlankDigit = BlankDigit & (~(1 << Digit_Num));
    }
}

