/*
 * File:   main.c
 * Author: Albertf
 *
 * Created on February 27, 2021, 3:01 PM
 */


#define BOARD_PROT_MPIDE_NPP 3

//pentru placa de dezvoltare
#if (BOARD_PROT_MPIDE_NPP == 3)
#define F_CPU 16000000
#define TMR1PERIOD 15999


//pentru Proteus
#elif (BOARD_PROT_MPIDE_NPP == 2)
#define F_CPU 8000000
#define TMR1PERIOD 7999

//pentru MPIDE SIM
#elif (BOARD_PROT_MPIDE_NPP == 1)
#define F_CPU 1000000
#define TMR1PERIOD 999

#endif

#include <avr/io.h>
#include <avr/interrupt.h>

#include "Uno_Nano_utils.h"
#include "Buttons.h"

#include "Uno_Nano_utils.h"
#include <string.h>
#include "ATMega_I2C.h"
#include "lcd_i2c.h"

#include <util/delay.h>



//Variabilele pentru butoane - Extern
extern enum BtnFlagTypes BtnFlag[NumButtons];
extern unsigned short BtnTimeCount[NumButtons];


char Msg1[20] = "Nume Prenume";
char Msg2[20] = "Hello World!";

int RefTemp = 21;



uint8_t i = 0;

void ConfigureandStartTimer1();

int GetTemperature();
void TurnOnOffHeater(uint8_t OnOff);

int main(void) {
//  int ReadTemp;
//  uint8_t OnOff = 0;

   
  
    
    //I2C, LCD
    I2CSetup(100000);
    LCD_Init();
    LCD_BackLight();
    //mesaj initial
    LCD_WriteStringAtPos(Msg1, 0, 0);
    

    
    Init_Buttons();
    ConfigureandStartTimer1();
    sei();
    
while(1) {
  
   switch(BtnFlag[BtnUp]){
      case Click: 
	          LCD_WriteStringAtPos("                ", 1, 0);
		      LCD_WriteStringAtPos("BtnU Click", 1, 0);
      		  BtnFlag[BtnUp] = BtnIdle;
		  break;
      case LPress: 
	          LCD_WriteStringAtPos("                ", 1, 0);
		      LCD_WriteStringAtPos("BtnU LongPress", 1, 0);
      		  BtnFlag[BtnUp] = BtnIdle;
		  break;
      case DblClick: 
	          LCD_WriteStringAtPos("                ", 1, 0);
		      LCD_WriteStringAtPos("BtnU DblClick", 1, 0);
      		  BtnFlag[BtnUp] = BtnIdle;
		  break;
      case LpRelease: 
	          LCD_WriteStringAtPos("                ", 1, 0);
		      LCD_WriteStringAtPos("BtnU LpRelease", 1, 0);
      		  BtnFlag[BtnUp] = BtnIdle;
		  break;
      default: break;
   }
   
   switch(BtnFlag[BtnDn]){
      case Click: 
	          LCD_WriteStringAtPos("                ", 1, 0);
		      LCD_WriteStringAtPos("BtnDn Click", 1, 0);
      		  BtnFlag[BtnDn] = BtnIdle;
		  break;
      case LPress: 
	          LCD_WriteStringAtPos("                ", 1, 0);
		      LCD_WriteStringAtPos("BtnDn LongPress", 1, 0);
      		  BtnFlag[BtnDn] = BtnIdle;
		  break;
      case DblClick: 
	          LCD_WriteStringAtPos("                ", 1, 0);
		  LCD_WriteStringAtPos("BtnDn DblClick", 1, 0);
      		  BtnFlag[BtnDn] = BtnIdle;
		  break;
      case LpRelease: 
	          LCD_WriteStringAtPos("                ", 1, 0);
		      LCD_WriteStringAtPos("BtnDn LpRelease", 1, 0);
      		  BtnFlag[BtnDn] = BtnIdle;
		  break;
      default: break;
   }
    

 }
}


ISR (TIMER1_COMPA_vect){
 
 enum Buttons Btn;
    //incrementam BtnTimeCount si rulam BtnFsm()
    //pentru fiecare buton
    for (Btn = BtnUp; Btn < NumButtons; Btn++){
        BtnTimeCount[Btn]++;
       BtnFSM(Btn);
    }
    
}


void ConfigureandStartTimer1(){
//Stergem configuratiile si resetam Timer
TCCR1A = 0;
TCCR1B = 0;
TCNT1 = 0; 
//Setam Perioada, vezi definitia
//la inceputul fisierului
OCR1A = TMR1PERIOD;
        
//Modul de lucru: CTC
BitSet(TCCR1B, WGM12);

// Valideaza Timer1 Interrupt pe Compare Match
BitSet(TIMSK1, OCIE1A);

//Alegem Prescaler=1 si pornim Timer
BitSet(TCCR1B, CS10);
}

