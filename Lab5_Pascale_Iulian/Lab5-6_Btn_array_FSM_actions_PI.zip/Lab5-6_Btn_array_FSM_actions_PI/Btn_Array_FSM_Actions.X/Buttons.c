
/* 
 * File:   
 * Author: 
 * Comments:
 * Revision history: 
 */


#include <avr/io.h>
#include <avr/interrupt.h>
#include "Uno_Nano_utils.h" 
#include "Buttons.h"

volatile enum BtnFsmStates BtnFSMState[NumButtons];

volatile enum BtnValues BtnVal[NumButtons];

volatile enum BtnFlagTypes BtnFlag[NumButtons];

volatile unsigned short BtnTimeCount[NumButtons];


uint8_t  * BTN_PIN_REGS[NumButtons]={(uint8_t *)_SFR_ADDR(PINB), 
                                     (uint8_t *)_SFR_ADDR(PINB)};

const uint8_t  BTN_PINS[NumButtons] ={PINB6, PINB5};




ISR(PCINT0_vect){
enum Buttons Btn;

     for (Btn = BtnUp; Btn < NumButtons; Btn++){
         
       if ( (BtnVal[Btn] == BtnReleased) &&
	    (bit_is_set_onAddr(BTN_PIN_REGS[Btn], BTN_PINS[Btn])) ){
	   if (BtnTimeCount[Btn] >= STABLE_TIME_TICKS) BtnVal[Btn]=BtnPressed;
	   BtnTimeCount[Btn]=0;
       }
       if ( (BtnVal[Btn] == BtnPressed) &&
	    (bit_is_clear_onAddr(BTN_PIN_REGS[Btn], BTN_PINS[Btn])) ){
	   if (BtnTimeCount[Btn] >= STABLE_TIME_TICKS) BtnVal[Btn]=BtnReleased;
	   BtnTimeCount[Btn]=0;
       }
    
     }
}

ISR(PCINT1_vect){
//E deocamdata gol,
//Avem butoane doar pe PCINT6 si PCINT5

}


ISR(PCINT2_vect){
//E deocamdata gol,
//Avem butoane doar pe PCINT6 si PCINT5
}


void BtnFSM(enum Buttons Btn){
    switch (BtnFSMState[Btn]){
    case stBtnIdle: if (BtnVal[Btn] == BtnPressed) 
                        BtnFSMState[Btn] = stBtnPressed;
                    break;
    case stBtnPressed: if (BtnVal[Btn] != BtnPressed){
                            BtnFSMState[Btn] = stBtnClick;
                            BtnFlag[Btn] = Click;
                        }
                      else
                        if(BtnTimeCount[Btn] == LONGPRESS_TICKS){
                               BtnFSMState[Btn] = stBtnLongPress;
                               BtnFlag[Btn] = LPress;
                        }
                    break;
    case stBtnClick: if (BtnTimeCount[Btn] >= DBLCLICK_TIMEOUT_TICKS)
                                BtnFSMState[Btn] = stBtnIdle;
                         else if(BtnVal[Btn] == BtnPressed){
                             BtnFSMState[Btn] = stBtnDblClick;
                             BtnFlag[Btn] = DblClick;
                         }
                         break;
    case stBtnDblClick: if (BtnVal[Btn] == BtnReleased)
                        BtnFSMState[Btn] = stBtnIdle;
                        break;
    case stBtnLongPress: if (BtnVal[Btn] == BtnReleased){
                            BtnFSMState[Btn] = stBtnIdle;
                            BtnFlag[Btn] = LpRelease;
                        }
                       break;
    default : break;
    } 
}

void Init_Buttons(){
    enum Buttons Btn;
    //Initializam toate variabilele legate de butoane
    for (Btn = BtnUp; Btn < NumButtons; Btn++){
        BtnFSMState[Btn]= stBtnIdle;
        BtnVal[Btn]=BtnReleased;
        BtnFlag[Btn]=BtnIdle;
        BtnTimeCount[Btn]=0;
    } 
    
    BitSet(PCMSK0, PCINT6); //PCINT6 = PB6, BtnUp
    BitSet(PCMSK0, PCINT5); //PCINT5 = PB5, BtnDn
    
    BitSet(PCICR, PCIE0);    //Validam vectorul de intrerupere, 
                             //care contine liniile PCINT6 si 5: PCINT0
			     

    
}


