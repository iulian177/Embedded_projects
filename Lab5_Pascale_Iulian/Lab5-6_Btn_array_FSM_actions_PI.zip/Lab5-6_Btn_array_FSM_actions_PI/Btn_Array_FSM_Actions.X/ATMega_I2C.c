/* ************************************************************************** */
/** Descriptive File Name

  @Company
    UTCN

  @File Name
   ATMega_I2C.c

  @Description
   I2C utilities for ATMega328p
 */
/* ************************************************************************** */

/* ************************************************************************** */
/* ************************************************************************** */
/* Section: Included Files                                                    */
/* ************************************************************************** */

#include "Uno_Nano_utils.h"
#include "ATMega_I2C.h"
/* ************************************************************************** */

/* ------------------------------------------------------------ */
/***    I2CSetup()
**
**	Parameters:
**		unsigned int Frequanecy: The SCL frequency at which I2C interface operates
**
**	Return Values:
**      none
**
**	Errors:
**		none
**
**	Description:
**	Configures the ATMega328p I2C for the desired frequency
**
*/
void I2CSetup(unsigned long Frequency){
//TBWR is calculated as
// ( (F_CPU/F_SCL) - 16) /(2*Prescaler)
//where F_CPU = 8 MHZ (defined above) and F_SCL - SCL clock frequency
//we will use Prescaler value of 1
    uint8_t Temp;
    Temp = (int)( ( ((float)F_CPU/Frequency)-16.0)/2.0 + 0.5);
    TWBR = Temp;
    
}

/* ------------------------------------------------------------ */
/***  unsigned char I2CWrite()
**
**	Parameters:
**		slaveAddress: the 7-bit address of the I2C slave
**      dataBuffer : pointer to the data to be written
**      NumBytes: number of data bytes to be written
**      StopCommand - can be
**                 STOP (1) - after the transfer a STOP command wil be issued on the I2C bus
**                 REPEATED_START - do not issue a STOP command. A Repeated Start will follow
**
**	Return Values:
**      0 - Transfer Successful, otherwise:
**      I2CSTA_SLA_W_NACK (0x20) - No acknowledge received from Slave after sending Address + Write, or
**      I2CSTA_DATA_W_NACK (0x30) - No acknowledge received from Slave after sending Data or
 *      1 - Transmit Error
**
**	Description:
**  Writes data to the I2C slave
**
*/

unsigned char I2C_Write (unsigned char slaveAddress,
                         unsigned char * dataBuffer,
                         unsigned char NumBytes,
                         unsigned char StopCommand){
    
uint8_t i=0;

//Send START command
TWCR = (1<<TWINT) | (1<<TWSTA) | (1<<TWEN);
while (bit_is_clear(TWCR, TWINT));//wait until START is sent
//Check Status
if (I2CStatus != I2CSTA_START_SENT) return I2CStatus;


//Send Slave Address + W
TWDR = (slaveAddress << 1);
TWCR = (1<<TWINT) | (1<<TWEN);
while (bit_is_clear(TWCR, TWINT));//wait until SLA+W is sent
//Check Status
if (I2CStatus != I2CSTA_SLA_W_ACK) return I2CStatus;

//Send Numbytes Data
for (i =0; i < NumBytes; i++){
    TWDR = *dataBuffer++;
    TWCR = (1<<TWINT) | (1<<TWEN);
    while (bit_is_clear(TWCR, TWINT));//wait until Data is sent
    //Check Status
    if (I2CStatus != I2CSTA_DATA_W_ACK) return I2CStatus;    
}

if (StopCommand == STOP){
//Send STOP command
TWCR = (1<<TWINT) | (1<<TWSTO) | (1<<TWEN);
}

return 0;

}


/* ------------------------------------------------------------ */
/***  unsigned char I2CRead()
**
**	Parameters:
**		slaveAddress: the 7-bit address of the I2C slave
**      dataBuffer : Read data buffer pointer
**      NumBytes: number of data bytes to be read
**
**	Return Values:
**      0 - Transfer Successful, otherwise:
**      I2CSTA_SLA_R_NACK (0x20) - No acknowledge received from Slave after sending Address + Read, or
**
**	Description:
**  Reads data from the I2C slave
**
*/
unsigned char I2C_Read  (unsigned char slaveAddress,
                        unsigned char * dataBuffer,
                        unsigned char NumBytes){
    
 uint8_t i=0;
 uint8_t Temp =0;

//Send START command
TWCR = (1<<TWINT) | (1<<TWSTA) | (1<<TWEN);
while (bit_is_clear(TWCR, TWINT));//wait until START is sent
//Check Status both for Start or Repeated Start Condition
if ( (I2CStatus != I2CSTA_START_SENT) && 
     (I2CStatus != I2CSTA_REP_START_SENT) ) return I2CStatus;


//Send Slave Address + R
TWDR = (slaveAddress << 1) | 1;
TWCR = (1<<TWINT) | (1<<TWEN);
while (bit_is_clear(TWCR, TWINT));//wait until SLA+W is sent
//Check Status
if (I2CStatus != I2CSTA_SLA_R_ACK) return I2CStatus;

//Receive Numbytes data
for (i =0; i < NumBytes; i++){
    //Send NACK to the last byte
    if (i == (NumBytes-1)){
        Temp = (1<<TWINT) | (1<<TWEN);
        //Clear Acknowledge bit
        Temp = Temp & ~(1<<TWEA);
        TWCR = Temp;
    }
    else//send Acknowledge bit
        TWCR = (1<<TWINT) | (1<<TWEA) | (1<<TWEN);
    while (bit_is_clear(TWCR, TWINT));//wait until Data is sent

    *dataBuffer=TWDR;
    dataBuffer++;
}

//Send Stop bit
TWCR = (1<<TWINT) | (1<<TWSTO) | (1<<TWEN);


return 0;   
 
}


/* *****************************************************************************
 End of File
 */
