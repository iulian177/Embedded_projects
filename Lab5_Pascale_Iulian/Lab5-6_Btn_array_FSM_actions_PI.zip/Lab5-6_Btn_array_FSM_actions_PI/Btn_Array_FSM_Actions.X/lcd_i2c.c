/* ************************************************************************** */
/** Descriptive File Name

  @Company
    Digilent

  @File Name
    lcd.c

  @Description
        This file groups the functions that implement the LCD library.
        The library implements control of the LCD device. 
        It is accessed in a "parallel like" approach. 
        Library provides functions for simple commands, displaying characters, handling user characters.
        Include the file together with config.h, utils.c and utils.h in the project when this library is needed.	
 
  @Author
    Cristian Fatu 
    cristian.fatu@digilent.ro
*/
/* ************************************************************************** */

/* ************************************************************************** */
/* ************************************************************************** */
/* Section: Included Files                                                    */
/* ************************************************************************** */
#include <avr/io.h>

#include <string.h>
#include "ATMega_I2C.h"
#include "lcd_i2c.h"
#include <util/delay.h>
/* ************************************************************************** */

static uint8_t LCD_BckLightOn = 0;

/* ------------------------------------------------------------ */
/***	LCD_Init
**
**	Parameters:
**		
**
**	Return Value:
**		
**
**	Description:
**		This function initializes the hardware used in the LCD module: 
**      The following digital pins are configured as digital outputs: LCD_DISP_RS, LCD_DISP_RW, LCD_DISP_EN
**      The following digital pins are configured as digital inputs: LCD_DISP_RS.
**      The LCD initialization sequence is performed, the LCD is turned on.
**          
*/
void LCD_Init()
{
     LCD_InitSequence(displaySetOptionDisplayOn);
}


/* ------------------------------------------------------------ */
/***	LCD_WriteByte
**
**	Parameters:
**		unsigned char bData - the data to be written to LCD, over the parallel interface
**
**	Return Value:
**		
**
**	Description:
**		This function writes a byte to the LCD. 
**      It implements the parallel write using LCD_DISP_RS, LCD_DISP_RW, LCD_DISP_EN, 
**      LCD_DISP_RS pins, and data pins. 
**      For a better performance, the data pins are accessed using a pointer to 
**      the register byte where they are allocated.
**      This is a low-level function called by LCD write functions, so user should avoid calling it directly.
**      The function uses pin related definitions from config.h file.
**      
**          
*/
void LCD_WriteByte(unsigned char bData, unsigned char bRS)
{
    LCD_WriteHighNibble(bData, bRS);
    LCD_WriteLowNibble(bData, bRS);
}

void LCD_WriteHighNibble(unsigned char bData, unsigned char bRS){

    uint8_t Temp = bData & 0xF0;
    //set RS if 1, set EN
    Temp = Temp | (bRS << RS_BIT)|(1 << E_BIT);
    
    if (LCD_BckLightOn) Temp = Temp | (1<<LED_BIT);
    
	// send data, RS and EN
    I2C_Write(LCD_I2C_ADDRESS, &Temp, 1, STOP);
    _delay_us(100);   
	// Clear En
	Temp = Temp & (~(1 << E_BIT));
    I2C_Write(LCD_I2C_ADDRESS, &Temp, 1, STOP);
    _delay_us(100);
    
}

void LCD_WriteLowNibble(unsigned char bData, unsigned char bRS){

    uint8_t Temp = ( (bData & 0x0F) << 4);
    //set RS if 1
    Temp = Temp | (bRS << RS_BIT)|(1 << E_BIT);
    
    if (LCD_BckLightOn) Temp = Temp | (1<<LED_BIT);
    
	// send data, RS and EN
    I2C_Write(LCD_I2C_ADDRESS, &Temp, 1, STOP);
    _delay_us(100);   
	// Clear En
	Temp = Temp & (~(1 << E_BIT));
    I2C_Write(LCD_I2C_ADDRESS, &Temp, 1, STOP);
    _delay_us(100);   
}

/* ------------------------------------------------------------ */
/***	LCD_WriteCommand
**
**	Parameters:
**		unsigned char bCmd -  the command code byte to be written to LCD
**
**	Return Value:
**		
**
**	Description:
**		Writes the specified byte as command. 
**      It clears the RS and writes the byte to LCD. 
**      The function uses pin related definitions from config.h file.
**      
**          
*/
void LCD_WriteCommand(unsigned char bCmd)
{ 
	// Write command byte RS = 0
	LCD_WriteByte(bCmd, 0);
}

/* ------------------------------------------------------------ */
/***	LCD_WriteDataByte
**
**	Parameters:
**		unsigned char bData -  the data byte to be written to LCD
**
**	Return Value:
**		
**
**	Description:
**      Writes the specified byte as data. 
**      It sets the RS and writes the byte to LCD. 
**      The function uses pin related definitions from config.h file.
**      This is a low-level function called by LCD write functions, so user should avoid calling it directly.
**      
**          
*/
void LCD_WriteDataByte(unsigned char bData)
{

	// Write data byte RS = 1
	LCD_WriteByte(bData, 1);
}


/* ------------------------------------------------------------ */
/***	LCD_InitSequence
**
**  Synopsis:
**              LCD_InitSequence(displaySetOptionDisplayOn);//set the display on
**
**	Parameters:
**		unsigned char bDisplaySetOptions -  display options
**					Possible options (to be OR-ed)
**						displaySetOptionDisplayOn - display ON
**						displaySetOptionCursorOn - cursor ON
**						displaySetBlinkOn - cursor blink ON
**
**	Return Value:
**		
**
**	Description:
**		This function performs the initializing (startup) sequence. 
**      The LCD is initialized according to the parameter bDisplaySetOptions. 
**      
**          
*/
void LCD_InitSequence(unsigned char bDisplaySetOptions)
{
	//	wait 40 ms
	_delay_ms(40);
	// Function Set
    LCD_WriteHighNibble(cmdLcdFcnInit, 0);
	// Wait ~4.1ms
	_delay_ms(5);
	// Function Set
	LCD_WriteHighNibble(cmdLcdFcnInit, 0);
	// Wait 100us
	_delay_us(100);
	LCD_WriteHighNibble(cmdLcdFcnInit, 0);
	// Wait ~100 us
    _delay_us(100);
	//Set 4-bit operation
    LCD_WriteHighNibble(cmdLcdFcn4Init, 0);
	// Wait ~100 us
    _delay_us(100);
	LCD_WriteCommand(cmdLcdFcn4Init);
	// Wait ~100 us
    _delay_us(100);	
    LCD_DisplaySet(bDisplaySetOptions);
	// Wait ~100 us
	_delay_us(100);
	// Display Clear
	LCD_DisplayClear();
	// Wait 1.52 ms
	_delay_us(1600);
    // Entry mode set
	LCD_WriteCommand(cmdLcdEntryMode);
    	// Wait 1.52 ms
	_delay_us(1600);
    
 }

/* ------------------------------------------------------------ */
/***	LCD_DisplaySet
**
**  Synopsis:
**				LCD_DisplaySet(displaySetOptionDisplayOn | displaySetOptionCursorOn);
**
**	Parameters:
**		unsigned char bDisplaySetOptions -  display options
**					Possible options (to be OR-ed)
**						displaySetOptionDisplayOn - display ON
**						displaySetOptionCursorOn - cursor ON
**						displaySetBlinkOn - cursor blink ON
**
**	Return Value:
**		
**
**	Description:
**      The LCD is initialized according to the parameter bDisplaySetOptions. 
**      If one of the above mentioned optios is not OR-ed, 
**      it means that the OFF action is performed for it.
**      
**          
*/
void LCD_DisplaySet(unsigned char bDisplaySetOptions)
{
	LCD_WriteCommand(cmdLcdCtlInit | bDisplaySetOptions);
}

/* ------------------------------------------------------------ */
/***	LCD_DisplayClear
**
**	Parameters:
**
**	Return Value:
**		
**	Description:
**      Clears the display and returns the cursor home (upper left corner, position 0 on row 0). 
**      
**          
*/
void LCD_DisplayClear()
{
	LCD_WriteCommand(cmdLcdClear);
    
    _delay_ms(2);
}

/* ------------------------------------------------------------ */
/***	LCD_ReturnHome
**
**
**	Parameters:
**
**	Return Value:
**		
**	Description:
**      Returns the cursor home (upper left corner, position 0 on row 0). 
**      
**          
*/
void LCD_ReturnHome()
{
	LCD_WriteCommand(cmdLcdRetHome);
}

/* ------------------------------------------------------------ */
/***	LCD_DisplayShift
**	Parameters:
**		unsigned char fRight - specifies display shift direction:
**				- 1 in order to shift right
**				- 0 in order to shift left
**
**	Return Value:
**		
**	Description:
**     Shifts the display one position right or left, depending on the fRight parameter.
**      
**          
*/
void LCD_DisplayShift(unsigned char fRight)
{
	unsigned char bCmd = cmdLcdDisplayShift | (fRight ? mskShiftRL: 0);
	LCD_WriteCommand(bCmd);
}

/* ------------------------------------------------------------ */
/***	LCD_CursorShift
**
**	Parameters:
**		unsigned char fRight
**				- 1 in order to shift right
**				- 0 in order to shift left
**
**	Return Value:
**		
**	Description:
**     Shifts the cursor one position right or left, depending on the fRight parameter.
**      
**          
*/
void LCD_CursorShift(unsigned char fRight)
{
	unsigned char bCmd = cmdLcdCursorShift | (fRight ? mskShiftRL: 0);
	LCD_WriteCommand(bCmd);
}

/* ------------------------------------------------------------ */
/***	LCD_WriteStringAtPos
**
**  Synopsis:
**      LCD_WriteStringAtPos("Demo", 0, 0);
**
**	Parameters:
**      char *szLn	- string to be written to LCD
**		int idxLine	- line where the string will be displayed
**          0 - first line of LCD
**          1 - second line of LCD
**		unsigned char idxPos - the starting position of the string within the line. 
**                                  The value must be between:
**                                      0 - first position from left
**                                      39 - last position for DDRAM for one line
**                                  
**
**	Return Value:
**		
**	Description:
**		Displays the specified string at the specified position on the specified line. 
**		It sets the corresponding write position and then writes data bytes when the device is ready.
**      Strings longer than 40 characters are trimmed. 
**      It is possible that not all the characters will be visualized, as the display only visualizes 16 characters for one line.
**      
**          
*/
void LCD_WriteStringAtPos(char *szLn, unsigned char idxLine, unsigned char idxPos)
{
	// crop string to 0x27 chars
	int len = strlen(szLn);
	if(len > 0x27)
	{
        szLn[0x27] = 0; // trim the string so it contains 40 characters 
		len = 0x27;
	}

	// Set write position
	unsigned char bAddrOffset = (idxLine == 0 ? 0: 0x40) + idxPos;
	LCD_SetWriteDdramPosition(bAddrOffset);

	unsigned char bIdx = 0;
	while(bIdx < len)
	{
		LCD_WriteDataByte(szLn[bIdx]);
		bIdx++;
	}
}

/* ------------------------------------------------------------ */
/***	LCD_SetWriteCgramPosition
**
**
**	Parameters:
**      unsigned char bAdr	- the write location. The position in CGRAM where the next data write operations will put bytes.
**
**	Return Value:
**		
**	Description:
**		Sets the DDRAM write position. This is the location where the next data write operation will be performed.
**		Writing to a location auto-increments the write location.
**      This is a low-level function called by LCD_WriteBytesAtPosCgram(), so user should avoid calling it directly.
 **      
**          
*/
void LCD_SetWriteCgramPosition(unsigned char bAdr)
{
	unsigned char bCmd = cmdLcdSetCgramPos | bAdr;
	LCD_WriteCommand(bCmd);
}

/* ------------------------------------------------------------ */
/***	LCD_WriteBytesAtPosCgram
**
**  Synopsis:
**      LCD_WriteBytesAtPosCgram(userDefArrow, 8, posCgramChar0);
**
**	Parameters:
**		unsigned char *pBytes	- pointer to the string of bytes
**		unsigned char len		- the number of bytes to be written
**		unsigned char bAdr		- the position in CGRAM where bytes will be written
**
**	Return Value:
**		
**	Description:
**		Writes the specified number of bytes to CGRAM starting at the specified position. 
**      This allows user characters to be defined.
**		It sets the corresponding write position and then writes data bytes when the device is ready.
**      
**          
*/
void LCD_WriteBytesAtPosCgram(unsigned char *pBytes, unsigned char len, unsigned char bAdr)
{
	// Set write position
	LCD_SetWriteCgramPosition(bAdr);

	// Write the string of bytes that define the character to CGRAM
	unsigned char idx = 0;
	while(idx < len)
	{
		LCD_WriteDataByte(pBytes[idx]);
		idx++;
	}
}

void LCD_BackLight(){
    LCD_BckLightOn = 1;
    LCD_ReturnHome();
}
void LCD_NoBackLight(){
    LCD_BckLightOn = 0;
    LCD_ReturnHome();
}

/* *****************************************************************************
 End of File
 */

