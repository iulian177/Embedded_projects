
/* 
 * File:   
 * Author: 
 * Comments:
 * Revision history: 
 */


#include <avr/io.h>
#include <avr/interrupt.h>
#include "Uno_Nano_utils.h" 
#include "Buttons.h"

volatile enum BtnFsmStates BtnFSMState[NumButtons];

volatile enum BtnValues BtnVal[NumButtons];

volatile enum BtnFlagTypes BtnFlag[NumButtons];

volatile unsigned short BtnTimeCount[NumButtons];


uint8_t  * BTN_PIN_REGS[NumButtons]={(uint8_t *)_SFR_ADDR(PIND), 
                                     (uint8_t *)_SFR_ADDR(PINB)};

const uint8_t  BTN_PINS[NumButtons] ={PIND5, PINB3};




ISR(PCINT0_vect){
enum Buttons Btn = BtnDn;

 //  for (Btn = BtnUp; Btn < NumButtons; Btn++){
         
       if ( (BtnVal[Btn] == BtnReleased) &&
	    (bit_is_set_onAddr(BTN_PIN_REGS[Btn], BTN_PINS[Btn])) ){
	   if (BtnTimeCount[Btn] >= STABLE_TIME_TICKS) BtnVal[Btn]=BtnPressed;
	   BtnTimeCount[Btn]=0;
       }
       if ( (BtnVal[Btn] == BtnPressed) &&
	    (bit_is_clear_onAddr(BTN_PIN_REGS[Btn], BTN_PINS[Btn])) ){
	   if (BtnTimeCount[Btn] >= STABLE_TIME_TICKS) BtnVal[Btn]=BtnReleased;
	   BtnTimeCount[Btn]=0;
       }
    
 //    }
}

ISR(PCINT1_vect){
//E deocamdata gol,
//Avem butoane doar pe PCINT21 si PCINT3

}


ISR(PCINT2_vect){
enum Buttons Btn = BtnUp;
         
       if ( (BtnVal[Btn] == BtnReleased) &&
	    (bit_is_set_onAddr(BTN_PIN_REGS[Btn], BTN_PINS[Btn])) ){
	   if (BtnTimeCount[Btn] >= STABLE_TIME_TICKS) BtnVal[Btn]=BtnPressed;
	   BtnTimeCount[Btn]=0;
       }
       if ( (BtnVal[Btn] == BtnPressed) &&
	    (bit_is_clear_onAddr(BTN_PIN_REGS[Btn], BTN_PINS[Btn])) ){
	   if (BtnTimeCount[Btn] >= STABLE_TIME_TICKS) BtnVal[Btn]=BtnReleased;
	   BtnTimeCount[Btn]=0;
       }
}


void BtnFSM(enum Buttons Btn){
    switch (BtnFSMState[Btn]){
    case stBtnIdle: if (BtnVal[Btn] == BtnPressed) 
                        BtnFSMState[Btn] = stBtnPressed;
                    break;
    case stBtnPressed: if (BtnVal[Btn] != BtnPressed){
                            BtnFSMState[Btn] = stBtnClick;
                            BtnFlag[Btn] = Click;
                        }
                      else
                        if(BtnTimeCount[Btn] == LONGPRESS_TICKS){
                               BtnFSMState[Btn] = stBtnLongPress;
                               BtnFlag[Btn] = LPress;
                        }
                    break;
    case stBtnClick: if (BtnTimeCount[Btn] >= DBLCLICK_TIMEOUT_TICKS)
                                BtnFSMState[Btn] = stBtnIdle;
                         else if(BtnVal[Btn] == BtnPressed){
                             BtnFSMState[Btn] = stBtnDblClick;
                             BtnFlag[Btn] = DblClick;
                         }
                         break;
    case stBtnDblClick: if (BtnVal[Btn] == BtnReleased)
                        BtnFSMState[Btn] = stBtnIdle;
                        break;
    case stBtnLongPress: if (BtnVal[Btn] == BtnReleased){
                            BtnFSMState[Btn] = stBtnIdle;
                            BtnFlag[Btn] = LpRelease;
                        }
                       break;
    default : break;
    } 
}

void Init_Buttons(){
    enum Buttons Btn;
    //Initializam toate variabilele legate de butoane
    for (Btn = BtnUp; Btn < NumButtons; Btn++){
        BtnFSMState[Btn]= stBtnIdle;
        BtnVal[Btn]=BtnReleased;
        BtnFlag[Btn]=BtnIdle;
        BtnTimeCount[Btn]=0;
    } 
    
    BitSet(PCMSK2, PCINT21); //PCINT21 = PD5, BtnUp
    BitSet(PCMSK0, PCINT3); //PCINT3 =  PB3, BtnDn
    
    BitSet(PCICR, PCIE0);    //Validam vectorii de intrerupere, 
    BitSet(PCICR, PCIE2);    //care contine liniile PCINT21 si 3: PCINT0 si PCINT2
			     

    
}


