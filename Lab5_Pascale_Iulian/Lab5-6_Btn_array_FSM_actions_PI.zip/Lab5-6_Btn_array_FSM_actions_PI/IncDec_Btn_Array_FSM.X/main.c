/*
 * File:   main.c
 * Author: Albertf
 *
 * Created on February 27, 2021, 3:01 PM
 */


#define BOARD_PROT_MPIDE_NPP 3

//pentru placa de dezvoltare
#if (BOARD_PROT_MPIDE_NPP == 3)
#define F_CPU 16000000
#define TMR1PERIOD 15999


//pentru Proteus
#elif (BOARD_PROT_MPIDE_NPP == 2)
#define F_CPU 8000000
#define TMR1PERIOD 7999

//pentru MPIDE SIM
#elif (BOARD_PROT_MPIDE_NPP == 1)
#define F_CPU 1000000
#define TMR1PERIOD 999

#endif

#include <avr/io.h>
#include <avr/interrupt.h>

#include "Uno_Nano_utils.h"
#include "Buttons.h"

#include "Uno_Nano_utils.h"
#include <string.h>
#include "ATMega_I2C.h"
#include "lcd_i2c.h"

#include <util/delay.h>



//Variabilele pentru butoane - Extern
extern enum BtnFlagTypes BtnFlag[NumButtons];
extern unsigned short BtnTimeCount[NumButtons];


char Msg1[20] = "Nume Prenume";
char Msg2[20] = "Hello World!";

int RefTemp = 21;



uint8_t i = 0;

void ConfigureandStartTimer1();

int GetTemperature();
void TurnOnOffHeater(uint8_t OnOff);

int main(void) {
//  int ReadTemp;
//  uint8_t OnOff = 0;

   
  
    
    //I2C, LCD
    I2CSetup(100000);
    LCD_Init();
    LCD_BackLight();
    
    //mesaj initial
    LCD_WriteStringAtPos(Msg1, 0, 0);
    
    sprintf(Msg2, "Temp = %.2d   ", RefTemp);
    LCD_WriteStringAtPos(Msg2, 1, 0);
    
    Init_Buttons();
    ConfigureandStartTimer1();
    sei();
    
while(1) {
  
    if (BtnFlag[BtnUp] == Click){
        RefTemp = RefTemp + 1;
        sprintf(Msg2, "Temp = %.2d   ", RefTemp);
        LCD_WriteStringAtPos(Msg2, 1, 0);
        BtnFlag[BtnUp] = BtnIdle;
    }
    if (BtnFlag[BtnDn] == Click){
        RefTemp = RefTemp - 1;
        sprintf(Msg2, "Temp = %.2d   ", RefTemp);
        LCD_WriteStringAtPos(Msg2, 1, 0);
        BtnFlag[BtnDn] = BtnIdle;
    }


 }
}


ISR (TIMER1_COMPA_vect){
 
 enum Buttons Btn;
    //incrementam BtnTimeCount si rulam BtnFsm()
    //pentru fiecare buton
    for (Btn = BtnUp; Btn < NumButtons; Btn++){
        BtnTimeCount[Btn]++;
       BtnFSM(Btn);
    }
    
}


void ConfigureandStartTimer1(){
//Stergem configuratiile si resetam Timer
TCCR1A = 0;
TCCR1B = 0;
TCNT1 = 0; 
//Setam Perioada, vezi definitia
//la inceputul fisierului
OCR1A = TMR1PERIOD;
        
//Modul de lucru: CTC
BitSet(TCCR1B, WGM12);

// Valideaza Timer1 Interrupt pe Compare Match
BitSet(TIMSK1, OCIE1A);

//Alegem Prescaler=1 si pornim Timer
BitSet(TCCR1B, CS10);
}

