/* 
 * File:   main.c
 * Author: pascale
 *
 * Created on March 24, 2024, 9:30 PM
 */

#include <stdio.h>
#include <stdlib.h>

#include <xc.h>
#include "Pic32Mx3Conf.h"
#include "utils.h"
#include "config.h"

//pentru 7-segment display (SSD)
#include <sys/attribs.h>
#include "ssd.h"

#define tris_BTN_BTNU TRISBbits.TRISB1
#define prt_BTN_BTNU PORTBbits.RB1
#define ansel_BTN_BTNU ANSELBbits.ANSB1

#define tris_BTN_BTND TRISAbits.TRISA15
#define prt_BTN_BTND PORTAbits.RA15
uint16_t Cnt = 27;

//RGBLED
#define tris_LED8_R   TRISDbits.TRISD2
#define lat_LED8_R    LATDbits.LATD2
#define ansel_LED8_R  ANSELDbits.ANSD2

#define tris_LED8_G   TRISDbits.TRISD12
#define lat_LED8_G    LATDbits.LATD12

uint16_t BTNU_Data[2] = {0, 0};
uint16_t BTND_Data[2] = {0, 0};      

uint16_t HexToBCD ( uint16_t number);

int main(int argc, char** argv) {

    //initializare
    ansel_BTN_BTNU = 0;
    tris_BTN_BTNU = 1;
    tris_BTN_BTND = 1;        
    
    //initializare RGB
    tris_LED8_G = 0;
    tris_LED8_R = 0;
    ansel_LED8_R = 0;
    
    uint16_t Temp = 0;
    
    //initializam SSD
    SSD_Init();
    
    
    while (1) {
        
        //esantionam
        BTNU_Data[0] = prt_BTN_BTNU;
        BTND_Data[0] = prt_BTN_BTND;   
        
        if ( BTNU_Data[0] && (!BTNU_Data[1])) {
            Cnt++;
            lat_LED8_G = 1;
        }
        else lat_LED8_G = 0;
        
        //actualizam esantionul BTNU
        BTNU_Data[1] = BTNU_Data[0]; 
        
        if ( BTND_Data[0] && (!BTND_Data[1])) {
            Cnt--;
            lat_LED8_R = 1;
        }
        else lat_LED8_R = 0;
        
        //actualizam esantionul BTND
        BTND_Data[1] = BTND_Data[0]; 
        
        Temp = HexToBCD(Cnt);
        SSD_WriteDigitsGrouped(Temp, 0);
        DelayAprox10Us(1000); //10ms
        
    }
    
    return (1);
}

uint16_t HexToBCD ( uint16_t number) {
    
    uint8_t i = 0;
    uint16_t Temp = 0;       
    
    if ( number > 9999 ) number = number / 10;
    
    while (number) {
        Temp = ( Temp ) | (( number % 10 ) << i*4);
        number /= 10;
        i++;
    }
    return (Temp);
    
}



