/* 
 * File:   main.c
 * Author: pascale
 *
 * Created on March 24, 2024, 9:30 PM
 */

#include <stdio.h>
#include <stdlib.h>

#include <xc.h>
#include "Pic32Mx3Conf.h"
#include "utils.h"



#define SECV 0x0A
uint8_t Val = SECV;
uint8_t i = 0;


int main(int argc, char** argv) {

    //initializare
    ANSELDbits.ANSD2 = 0;
    
    //iesiri cu registrii SET, CLR
    TRISDCLR = 0x04;  //led8_R
    TRISACLR = 0x81;  //LD0 si LD7
    
    //valori initiale
    LATDSET = 0x04 ; //led8_R
    LATACLR = 0x01 ; //LD0
    LATASET = 0x80; //LD7
    
    //din biblioteca Digilent
    DelayAprox10Us(1);
    
    while (1) {
        Val = SECV ;
        for( i = 0; i < 5; i++ ) {
            //se modif secv
            //pe frontul negativ a lui RD2 = semnal A (clock)  
            PORTD = PORTD & (~(1 << 2));  //sau 0xFB
            
            //aici cu union RA0 - B          
            if ( Val & 0x01 )
                LATAbits.LATA0 = 0x01;
            else LATAbits.LATA0 = 0x00;          
            Val = Val >> 1;
            DelayAprox10Us(1);
                
            // front pozitiv RD2
            PORTD = PORTD | (1 << 2);
            DelayAprox10Us(1);
            
        }
    }
    
    return (1);
}

