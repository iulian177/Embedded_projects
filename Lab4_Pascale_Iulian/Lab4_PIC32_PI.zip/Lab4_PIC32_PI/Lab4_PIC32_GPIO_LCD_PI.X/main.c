/* 
 * File:   main.c
 * Author: pascale
 *
 * Created on April 8, 2024, 5:31 PM
 */

#include <stdio.h>
#include <stdlib.h>

#include <xc.h>
#include "Pic32Mx3Conf.h"
#include "utils.h"
#include "config.h"
#include "lcd.h"

#define DlyTime 100000
#define SECV 0x50  //0101_0000

#define Out1 0x10  //bitul 4
#define Out2 0x04  //bitul 2

uint8_t Val = SECV;
uint8_t i;

int main(int argc, char** argv) {

    TRISAbits.TRISA2 = 0;
    TRISAbits.TRISA4 = 0;
    
    LCD_Init();
    
    //val initiale
    LATAbits.LATA2 = 0;
    LATAbits.LATA4 = 1;        
    DelayAprox10Us(DlyTime);
    
    while(1) {
        
        LCD_DisplayClear();
        LCD_WriteStringAtPos("LED4:", 0, 0);
        LCD_WriteStringAtPos("LED2:", 1, 0);
        
        Val = SECV;
        for( i = 0; i < 5; i++ ) {
            
            //front pozitiv Out1
            LATASET = Out1;
            LCD_WriteStringAtPos("1", 0, 5 + i*2);
            
            //atribuire iesiri Out2
            if ( Val & 0x80 ) {
                LATASET = Out2;
                LCD_WriteStringAtPos("1", 1, 5 + i*2);
            }
            else { LATACLR = Out2; 
                   LCD_WriteStringAtPos("0", 1, 5 + i*2);
            }
            Val = Val << 1;
            DelayAprox10Us(DlyTime);
            
            //front negativ Out1
            LATACLR = Out1;
            LCD_WriteStringAtPos("0", 0, 5 + i*2 + 1);
            DelayAprox10Us(DlyTime);
        }
        
    }
    
    return (EXIT_SUCCESS);
}

