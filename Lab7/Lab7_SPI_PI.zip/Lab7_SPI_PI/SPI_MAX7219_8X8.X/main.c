/* 
 * File:   main.c
 * Author: Albertf
 *
 * Created on March 7, 2020, 8:14 AM
 */

#define PLACA 1

#include <stdio.h>
#include <stdlib.h>
#include "string.h"

#include <avr/io.h>
#include <avr/interrupt.h> //obligatoriu, daca folosim intreruperi
#include "Uno_Nano_utils.h"

#include "ATMega_Uart.h"

#include "ATMega_SPI.h"


#if (PLACA)
#define F_CPU 16000000UL
#define TIMER1_FREQUENCY_HZ 1000
#define STABLE_TIME_TICKS 3
#else
#define TIMER1_FREQUENCY_HZ 1000
#define STABLE_TIME_TICKS 3
#endif

//MAX7219 Definitions
#define NOP        0x00
#define DECODE     0x09
#define INTENSITY  0x0A
#define SCAN_LIMIT 0x0B
#define SHUTDOWN   0x0C
#define DISP_TEST  0x0F

const uint8_t ConfigValues[10] ={   
    SHUTDOWN,   0x01, //No Shutdown
    DISP_TEST,  0x00, //No Display Test Mode
    DECODE,     0x00, //No decode
    INTENSITY,  0x0F, //0x07 = 15/32 intensity
    SCAN_LIMIT, 0x07 //Display all columns/digits
    };


//Triangle
//const uint8_t Matrix_Data[8] ={ 0x01, 0x03, 0x07, 0x0F, 0x1F, 0x3F, 0x7F, 0xFF};

//A character
//const uint8_t Matrix_Data[8] ={ 0x00, 0x7c, 0x12, 0x11, 0x12, 0x7c, 0x00, 0x00};

//P character
const uint8_t Matrix_Data[8] ={ 0x00, 0x00, 0x7F, 0x09, 0x09, 0x0F, 0x00, 0x00};

//Incremental numbers
//const uint8_t Matrix_Data[8] ={ 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08};

//Percent 00 sign
//const uint8_t Matrix_Data[8] = {8, 99, 19, 8, 100, 99, 96, 96};


volatile unsigned short TimebaseCount = 0;
volatile uint8_t Timebase_Tick = 0;

enum BtnStates{Released, Pressed};
volatile enum BtnStates BtnState = Released;
volatile unsigned short BTNTimeCount=0;

void ConfigureandStartTimer1();

FILE uart_str = FDEV_SETUP_STREAM(uart_putchar, uart_getchar, _FDEV_SETUP_WRITE);

uint16_t SwapEndian(uint16_t Num){
    return (Num >> 8) | (Num << 8);
}

int main(int argc, char** argv) {
    
    int i;
    uint16_t dSend, dRec;
    uint16_t DataRec[6];
    
    //Initial SS este inactiv
    BitSet(PORT_SS, SS_PIN);
        
    BitSet(PCMSK2, PCINT21); //PCINT21 = PD5
    BitSet(PCICR, PCIE2);    //Validam vectorul de intrerupere, 
                             //care contine bitul PCINT21: PCIE2
    
    ConfigureUart();
    SPISetup();
    
    ConfigureandStartTimer1();
    
    stdout = stdin = &uart_str;
    
	sei();  
    
    printf("\r\nConfiguring MAX7219, press BTN to continue");
    while (BtnState != Pressed);
    while (BtnState == Pressed);
    
    
    /************************************
    * Configurarea MAX7219
    **********************************/
    for (i =0; i < 5; i++){
        printf("\r\nData to send: 0x%02X, 0x%02X", 
                ConfigValues[2*i], ConfigValues[2*i+1]);
    }

            
    for (i =0; i < 5; i++){
        BitClear(PORT_SS, SS_PIN);
        
        //dSend = (ConfigValues[2*i] << 8) | ConfigValues[2*i+1];
        //Din cauza Endianness, trebuie schimbati octetii
        //Octet High trece in low si invers
        dSend = (ConfigValues[2*i+1] << 8) | ConfigValues[2*i];
        
        SPITransfer((uint8_t *)&dSend, (uint8_t *)&dRec, 2);
        
        //DataRec[i] = SwapEndian(dRec);
        //Si la datele receptionate, trebuie schimbati octetii
        DataRec[i] = SwapEndian(dRec);
        BitSet(PORT_SS, SS_PIN); 
    }
    
    //le citim pe 16 biti!
    for (i = 0; i < 5; i++){
        printf("\r\nData received = 0X%04X", DataRec[i]);
    }
   
    printf("\r\nSendig data to MAX7219, press BTN to continue");
    while (BtnState != Pressed);
    while (BtnState == Pressed);
    
    /************************************
     * Afisarea formei geometrice
     ***********************************/
    for (i = 0; i < 8; i++){
        BitClear(PORT_SS, SS_PIN);
        //Din cauza Endianness, trebuie schimbati octetii
        //Octet High trece in low si invers
        dSend = ( (Matrix_Data[i] << 8) | (i+1) );

        SPITransfer((uint8_t *)&dSend, (uint8_t *)&dRec, 2);

        //Si la datele receptionate, trebuie schimbati octetii
        DataRec[i] = SwapEndian(dRec);
        BitSet(PORT_SS, SS_PIN); 
    }
    printf("\r\nData Sent, check display");
    
    while (1);
    
}


ISR (TIMER1_COMPA_vect){
    
    BTNTimeCount++;
    
    TimebaseCount++;
    if (TimebaseCount == 2000){
        TimebaseCount = 0;
        Timebase_Tick = 1;
    }
    
}

ISR(PCINT2_vect){
  if(BTNTimeCount >= STABLE_TIME_TICKS){    
    if (bit_is_set(PIND, PIND5)){
        BtnState = Pressed;
    }
    else{
        BtnState = Released;
    }
  }
  BTNTimeCount = 0;
}



void ConfigureandStartTimer1(){
//Stergem configuratiile si resetam Timer
TCCR1A = 0;
TCCR1B = 0;
TCNT1 = 0; 
//Setam Perioada
OCR1A = 7999;
//Modul de lucru
BitSet(TCCR1B, WGM12);

// Valideaza Timer1 Interrupt pe Compare Match
BitSet(TIMSK1, OCIE1A);

//Alegem Prescaler=1 si pornim Timer
BitSet(TCCR1B, CS10);
}

