/* ************************************************************************** */
/** Descriptive File Name

  @Company
    UTCN

  @File Name
   ATMega_Uart.c

  @Description
    UART utilities for ATMega328p
 */
/* ************************************************************************** */

/* ************************************************************************** */
/* ************************************************************************** */
/* Section: Included Files                                                    */
/* ************************************************************************** */

#include "ATMega_Uart.h"
#include "Uno_Nano_utils.h"
#include "ATMega_SPI.h"
/* ************************************************************************** */

/* ------------------------------------------------------------ */
/***    SPIStetup()
**
**	Synopsis:
**		SPISetup)()
**
**	Parameters:
**		none
**
**	Return Values:
**      none
**
**	Errors:
**		none
**
**	Description:
**	Configures the ATMega328p UART for 9600 baudrate, 8 data bits, no parity, 1 stop bit
**  i.e. 9600-8-N-1
**
*/
void SPISetup(){
       
    BitSet(PORT_SPI_DIR, SCK_DIR);//SCK-iesire
    BitSet(PORT_SPI_DIR, MOSI_DIR);//MOSI-iesire
    BitSet(PORT_SS_DIR, SS_DIR);//SS- iesire

    //Fosc/64 = 16MHz/64 = 250KHz
    BitSet(SPSR, SPI2X);
    BitSet(SPCR, SPR0);
    BitSet(SPCR, SPR1);
   
    //Mode = 0
    BitClear(SPCR, CPOL);
    BitClear(SPCR, CPHA); 
    
    BitSet(SPCR, MSTR);//Master Mode
    BitSet(SPCR, SPE);//Enable SPI
}



void SPITransfer(uint8_t * pSend, uint8_t * pRecv, uint8_t ByteCount){
   uint8_t i;
   
   for (i = 0; i < ByteCount; i++){
    SPDR = *pSend++;
    while (bit_is_clear(SPSR, SPIF));
    *pRecv++ = SPDR;
   }
}



/* *****************************************************************************
 End of File
 */
