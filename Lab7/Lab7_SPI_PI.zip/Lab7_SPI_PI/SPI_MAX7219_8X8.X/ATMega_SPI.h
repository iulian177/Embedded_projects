/* ************************************************************************** */
/** Descriptive File Name

  @Company
    Digilent

  @File Name
    utils.h

  @Description
    This file groups the declarations of the functions that implement
        the utils library (defined in utils.c).
        Include the file in the project when this library is needed.
        Use #include "utils.h" in the source files where the functions are needed.
 */
/* ************************************************************************** */

#ifndef _ATMEGA_SPI_H    /* Guard against multiple inclusion */
#define _ATMEGA_SPI_H



#include <stdio.h>
#include <avr/io.h>
#include "ATMega_Uart.h"
#include "Uno_Nano_utils.h"

/************************************************
 *  SPI PORT DEFINITIONS
 ***********************************************/

#define PORT_SPI PORTB
#define PORT_SPI_DIR DDRB
#define SCK_DIR DDB5
#define SCK_PIN PB5

#define MOSI_DIR DDB3
#define MOSI_PIN  PB3
#define MISO_DIR DDB4
#define MISO_PIN PB4

#define PORT_SS PORTB
#define PORT_SS_DIR DDRB
#define SS_DIR DDB2
#define SS_PIN PB2


void SPISetup();

void SPITransfer(uint8_t * pSend, uint8_t * pRecv, uint8_t ByteCount);



#endif /* _ATMEGA_SPI_H */

/* *****************************************************************************
 End of File
 */
