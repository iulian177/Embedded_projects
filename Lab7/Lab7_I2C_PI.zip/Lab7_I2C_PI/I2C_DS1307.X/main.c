/*
 * File:   main.c
 * Author: Albertf
 *
 */

#define PLACA 1

#include <avr/io.h>
#include <avr/interrupt.h>

#include "Uno_Nano_utils.h"
#include <string.h>
#include "ATMega_I2C.h"
#include "ATMega_Uart.h"


#if (PLACA)
#define TIMER1_FREQUENCY_HZ 1000
#define STABLE_TIME_TICKS 3
#else
#define TIMER1_FREQUENCY_HZ 1000
#define STABLE_TIME_TICKS 3
#endif


//Definitii DS1307
#define DS1307_ADDRESS 0x68
//DS1307_DATA_SIZE este, de fapt, 7
//Dar il marim cu 1
//La scriere, primul octet din sir
//va fi pointer de adrese
#define DS1307_DATA_SIZE 8
#define CN_BIT 7

#define ADDR_POINTER 0
#define SECONDS_REG  1
#define MINUTES_REG  2
#define HOURS_REG    3
#define DAY_REG      4
#define DATE_REG     5
#define MONTH_REG    6
#define YEAR_REG     7


volatile unsigned short TimebaseCount = 0;
volatile uint8_t Timebase_Tick = 0;

enum BtnStates{Released, Pressed};
volatile enum BtnStates BtnState = Released;
volatile unsigned short BTNTimeCount=0;

void ConfigureandStartTimer1(uint16_t Frequency);


FILE uart_str = FDEV_SETUP_STREAM(uart_putchar, uart_getchar, _FDEV_SETUP_WRITE);


int main(void) {
    uint8_t Status = 0;
    uint8_t RTC[DS1307_DATA_SIZE];
    //pointer la sirul RTC
    uint8_t * pRTC = RTC;
    uint8_t i;

    BitSet(PCMSK2, PCINT21); //PCINT21 = PD5
    BitSet(PCICR, PCIE2);    //Validam vectorul de intrerupere, 
                             //care contine bitul PCINT21: PCIE2
    I2CSetup(100000);
    ConfigureUart();
    
    ConfigureandStartTimer1(TIMER1_FREQUENCY_HZ);
    
    stdout = stdin = &uart_str;
    
	sei();                   //Validam global intreruperile
    
    printf("\r\nConfiguring DS1307, press BTN to continue");
    //Asteptam dupa apasarea butonului
    while (BtnState!= Pressed); 
    while (BtnState== Pressed); 

     printf("\r\nBtn pressed");
    //Prima data verificam comunicarea cu DS1307
    //Daca avem eroare de comunicare, oprim programul
    //Setam doar pointerul la 0
    RTC[ADDR_POINTER] = 0x0;
    pRTC= RTC;
    Status = I2C_Write (DS1307_ADDRESS, pRTC, 1, STOP);
    
    //Verificam, daca dupa primul acces avem eroare
    if (Status){
        printf("\r\nCommunication Error, Status = 0x%X", Status);
        if (Status == I2CSTA_SLA_W_NACK){
            printf("\r\nSlave did not acknowledge, NAK received");
        }
        //Oprim programul, daca prima comunicare a fost eronata
        return Status;
    }
    
    //Asteptam pana la inceperea urmatoarei operatii I2C
    DelayAprox10Us(1);
    

    printf("\r\nSetting Time, press BTN to continue");
    //Asteptam dupa apasarea butonului
    while (BtnState!= Pressed); 
    while (BtnState== Pressed); 

    //Prima data pointer-ul de adresa
    RTC[ADDR_POINTER] = 0x0;
    //Bitul 7 in registrul de secunde e 0.
    //Daca scriem valoarea registrului de secunde,
    //atunci va porni ceasul
    RTC[SECONDS_REG]  = 0x55;
                
    RTC[MINUTES_REG]  = 0x15;
    RTC[HOURS_REG]    = 0x16;
    //decamdata setam ziua din sapatamana 
    //pe prima zi. Acesta poate fi Dum sau Luni
    RTC[DAY_REG]      = 0x01;
    RTC[DATE_REG]     = 0x03;
    RTC[MONTH_REG]    = 0x06;
    RTC[YEAR_REG]     = 0x24;//doar 2 cifre
                            //La afisare vom adauga 2000
    pRTC = RTC;
    Status = I2C_Write (DS1307_ADDRESS, pRTC, 8, STOP);
   
    //Stergem sirul RTC
    //ca sa ne asiguram ca sigur citim datele de pe I2C
    for (i = 0; i < 8; i++) RTC[i] = 0;

    
    //Citim in continu data si ora 
while(1) {

    if (Timebase_Tick){

        //Setam pointer pe registrul 0
        RTC[ADDR_POINTER] = 0x0;
        pRTC = RTC;
        Status = I2C_Write (DS1307_ADDRESS, pRTC, 1, REPEATED_START);

        //Citim octetii de ora si data
        pRTC = RTC + SECONDS_REG;
        Status = I2C_Read(DS1307_ADDRESS, pRTC, DS1307_DATA_SIZE-1);

        //Afisam 
        printf("\n\rDate: %X.%02X.20%02X, Time: %X:%02X:%02X", 
                RTC[DATE_REG], RTC[MONTH_REG],RTC[YEAR_REG], RTC[HOURS_REG], 
                RTC[MINUTES_REG], RTC[SECONDS_REG]);
    
    Timebase_Tick = 0;
    
    }
 }
}

ISR (TIMER1_COMPA_vect){
    
    BTNTimeCount++;
    
    TimebaseCount++;
    if (TimebaseCount == 500){
        TimebaseCount = 0;
        Timebase_Tick = 1;
    }

}

ISR(PCINT2_vect){
  if(BTNTimeCount >= STABLE_TIME_TICKS){    
    if (bit_is_set(PIND, PIND5)){
        BtnState = Pressed;
    }
    else{
        BtnState = Released;
    }
  }
  BTNTimeCount = 0;
}



void ConfigureandStartTimer1(uint16_t Frequency){
//Stergem configuratiile si resetam Timer
TCCR1A = 0;
TCCR1B = 0;
TCNT1 = 0; 
//Setam Perioada
//Setam Perioada
OCR1A = 15999;
//Modul de lucru
BitSet(TCCR1B, WGM12);

// Valideaza Timer1 Interrupt pe Compare Match
BitSet(TIMSK1, OCIE1A);

//Alegem Prescaler=1 si pornim Timer
BitSet(TCCR1B, CS10);
}
