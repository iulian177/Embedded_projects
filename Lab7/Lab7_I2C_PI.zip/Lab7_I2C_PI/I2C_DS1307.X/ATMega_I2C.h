/* ************************************************************************** */
/** Descriptive File Name

  @Company
    Digilent

  @File Name
    utils.h

  @Description
    This file groups the declarations of the functions that implement
        the utils library (defined in utils.c).
        Include the file in the project when this library is needed.
        Use #include "utils.h" in the source files where the functions are needed.
 */
/* ************************************************************************** */

#ifndef _ATMEGA_I2C_H    /* Guard against multiple inclusion */
#define _ATMEGA_I2C_H

#ifdef __cplusplus
extern "C" {
#endif


#include <stdio.h>
#include <avr/io.h>
#include "Uno_Nano_utils.h"

//UL in definitie inseamna UNSIGNED LONG
//adica, compilatorul sa trateze numarul definit ca un Unsigned Long (32 biti)
#define F_CPU 16000000UL

/************************************************
 *  I2C PORT Status DEFINITIONS
 ***********************************************/
#define I2CStatus (TWSR & 0xF8)

/**************************************
 I2C Status in Master Transmitter Mode
 **************************************/
#define I2CSTA_START_SENT 0x08
#define I2CSTA_REP_START_SENT 0x10
#define I2CSTA_SLA_W_ACK 0x18
#define I2CSTA_SLA_W_NACK 0x20
#define I2CSTA_DATA_W_ACK 0x28
#define I2CSTA_DATA_W_NACK 0x30
#define I2CSTA_ARB_LOST 0x38

/**************************************
 I2C Status in Master Receiver Mode
 **************************************/
#define I2CSTA_START_SENT 0x08
#define I2CSTA_REP_START_SENT 0x10
#define I2CSTA_SLA_R_ACK 0x40
#define I2CSTA_SLA_R_NACK 0x48
#define I2CSTA_DATA_R_ACK 0x50
#define I2CSTA_DATA_R_NACK 0x58
#define I2CSTA_ARB_LOST 0x38


#define STOP 1
#define REPEATED_START 0


void I2CSetup(unsigned long Frequency);

unsigned char I2C_Write (unsigned char slaveAddress,
                unsigned char * dataBuffer,
                unsigned char NumBytes,
                unsigned char StopCommand);

unsigned char I2C_Read  (unsigned char slaveAddress,
                unsigned char * dataBuffer,
                unsigned char NumBytes);

#ifdef __cplusplus
}
#endif

#endif /* _ATMEGA_I2C_H */

/* *****************************************************************************
 End of File
 */
