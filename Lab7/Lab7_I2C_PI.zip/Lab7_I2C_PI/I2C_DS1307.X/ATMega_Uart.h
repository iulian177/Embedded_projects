/* ************************************************************************** */
/** Descriptive File Name

  @Company
    Digilent

  @File Name
    utils.h

  @Description
    This file groups the declarations of the functions that implement
        the utils library (defined in utils.c).
        Include the file in the project when this library is needed.
        Use #include "utils.h" in the source files where the functions are needed.
 */
/* ************************************************************************** */

#ifndef _UART_H    /* Guard against multiple inclusion */
#define _UART_H

#include <ctype.h>
#include <stdint.h>
#include <stdio.h>

void ConfigureUart();

void putch(char data);

void UART_WriteString(const char *p);

/*******************************************
*From ..winavrdoc\avr-libc\examples\stdiodemo
*********************************************/
/*
 * Send one character to the UART.
 */
int	uart_putchar(char c, FILE *stream);

/*
 * Size of internal line buffer used by uart_getchar().
 */
#define RX_BUFSIZE 80

/*
 * Receive one character from the UART.  The actual reception is
 * line-buffered, and one character is returned from the buffer at
 * each invokation.
 */
int	uart_getchar(FILE *stream);


#endif /* _UART_H */

/* *****************************************************************************
 End of File
 */
