/*
 * File:   main.c
 * Author: pascale
 *
 * Created on March 23, 2024, 11:16 AM
 */

#define BOARD_PROT_MPIDE_PI 1

//pentru placa de dezvoltare
#if (BOARD_PROT_MPIDE_PI == 3)
#define F_CPU 16000000
#define DlyTime 1000
#define Delay_PI(X) _delay_ms(X)

//pt Proteus
#elif (BOARD_PROT_MPIDE_PI == 2)
#define DlyTime 200
#define Delay_PI(X) _delay_ms(X)

//pentru MPIDE SIM
#elif (BOARD_PROT_MPIDE_PI == 1)
#define DlyTime_PI 100
#define Delay_PI(X) _delay_us(X)
#endif


#include <avr/io.h>
#include <util/delay.h>
#include "Uno_Nano_utils.h"


#define SECV 0x50
uint8_t Val = SECV;
uint8_t i = 0;

int main(void) {
    
    
        
    while (1) {
        
        Val = SECV;
        
        BitSet(DDRB, 1);      
        BitSet(DDRB, 3);
        BitSet(DDRD, 4);
        BitSet(DDRD, 5);
        
        //valori initiale
        BitSet(PORTB, 1);  
        BitSet(PORTB, 3);  
        BitSet(PORTD, 4); 
        BitClear(PORTD, 5);
         
        Delay_PI(DlyTime_PI);
        
        for(i = 0; i < 5; i++) {
            
            //front negativ clock PB1
            
            PORTB = PORTB & (~(1<<1));
            //BitClear(PORTB, 1);
            
            //atribuire PD5
            //se shifteaza Secventa; masca fixa
            
            if (Val & 0x80) PORTD = PORTD |(1<<5);  
                //BitSet(PORTD, 5);                
            else PORTD = PORTD & (~(1<<5));
                //BitClear(PORTD, 5);  
            Val = Val << 1;            
                    
            Delay_PI(DlyTime_PI);
            
            //front pozitiv clock
            
            PORTB = PORTB | (1<<1);
            //BitSet(PORTB, 1);  
            Delay_PI(DlyTime_PI);
        } 
        
    }
}
