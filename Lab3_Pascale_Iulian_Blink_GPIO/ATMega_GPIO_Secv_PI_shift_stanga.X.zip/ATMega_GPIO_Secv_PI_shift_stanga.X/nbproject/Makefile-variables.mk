#
# Generated - do not edit!
#
# NOCDDL
#
CND_BASEDIR=`pwd`
# default configuration
CND_ARTIFACT_DIR_default=dist/default/production
CND_ARTIFACT_NAME_default=ATMega_GPIO_Secv_PI_shift_stanga.X.production.hex
CND_ARTIFACT_PATH_default=dist/default/production/ATMega_GPIO_Secv_PI_shift_stanga.X.production.hex
